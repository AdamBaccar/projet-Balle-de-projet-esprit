from django.contrib import admin
from .models import TunisiaGovernorate, LaborMarketStats

admin.site.register(TunisiaGovernorate)
admin.site.register(LaborMarketStats)
